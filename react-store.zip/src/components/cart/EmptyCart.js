import React from 'react';

const EmptyCart = () => {
    return (
        <div className="container mt-5">
            <div className="row">
                <div class="col-10 mx-auto text-center title">
                    <h1>Your cart is currently empty.</h1>
                </div>
            </div>
        </div>
    );
}

export default EmptyCart;
